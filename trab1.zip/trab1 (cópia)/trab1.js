$("header").append("<div class='glitch-window'></div>");
//fill div with clone of real header
$( "h1.glitched" ).clone().appendTo( ".glitch-window" );


function imc(){

    let img = document.getElementById("img");
    var altura = parseInt(document.getElementById("altura").value);
    var peso = parseInt(document.getElementById("peso").value);
    var altura1 = altura / 100;
    var resultado = (peso / (altura1 * altura1));

    

    const ele = document.querySelector("input[name='opcao']:checked").value;
    if (ele == "1") 
    {
        document.getElementById("tipo").innerHTML = "→Escolha:  Adulto";
        if (resultado < 18.5)
        {   
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Magreza";
            img.src = "img/pessoas/1.png";
            createMessage("CUIDADO! Você Está Abaixo do Peso", "alert")
        }
        else if(resultado > 18.5 && resultado <=  24.9)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Peso Normal";
            img.src = "img/pessoas/2.png";
            createMessage("Seu Peso Está Ótimo", "sucess")
        }
        else if(resultado > 24.9 && resultado <= 29.9)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Sobrepeso";
            img.src = "img/pessoas/3.png";
            createMessage("CUIDADO! Você Está com Sobrepeso", "warning")
        }
        else if(resultado > 29.9 && resultado <= 34.9)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Obesidade grau I";
            img.src = "img/pessoas/4.png";
            createMessage("CUIDADO! Você Está com Obesidad grau I", "warning")
        }
        else if(resultado > 34.9 && resultado <= 40)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Obesidade grau II";
            img.src = "img/pessoas/5.png";
            createMessage("CUIDADO! Você Está com Obesidade grau II", "alert")
        }
        else if(resultado > 40)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Obesidade grau III";
            img.src = "img/pessoas/6.png";
            createMessage("CUIDADO! Você Está com Obesidade grau III", "danger")
        }
    }

    else if (ele == "2"){
        document.getElementById("tipo").innerHTML = "→Escolha:   Velho";
        if (resultado < 22){
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Magreza/Abaixo do Peso";
            img.src = "img/pessoas/1.png";
            createMessage("CUIDADO! Você Está Abaixo do Peso", "alert")
        }
        else if(resultado > 22 && resultado <= 27)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação: → Peso Normal";
            img.src = "img/pessoas/2.png";
            createMessage("Seu Peso Está Ótimo", "sucess")
        }
        else if(resultado > 27)
        {
            document.getElementById("imc").innerHTML = "→Resultado do IMC:   " + (resultado.toFixed(2));
            document.getElementById("cl").innerHTML = "→Classificação:  Obesidade/Acima do Peso";
            img.src = "img/pessoas/5.png";
            createMessage("CUIDADO! Você Está Acima do Peso", "alert")

        }
    }
}




function createMessage(msg, type) {
    document
      .querySelector("body")
      .insertAdjacentHTML("beforebegin", `<div class='message ${type}'>${msg}</div>`);
  
    setTimeout(function () {
      deleteMessage();
    }, 3000);
  }
















































































































































//https://franciscochaves.com.br/blog/calcule-imc-com-javascript


//console.log(selectedRadio) // Valor do input selecionado
